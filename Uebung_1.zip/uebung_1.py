#!/usr/bin/env python
# -*- coding: utf-8 -*-

#Sentiment Analyse und Media Monitoring
#### NAME ####
### DATUM #####



################




def get_documents():
	
	

def get_features(documents):
		
	
	
def get_more_features(documents):
	

def featuresets(features, documents):


def train_test(features_sets, documents):
	
    
def main():
	
	
	
if __name__ == '__main__':
    main()

